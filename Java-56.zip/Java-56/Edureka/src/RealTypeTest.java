
public class RealTypeTest {

	public static void main(String[] args) {
		//float sal = 123.45F;
		float sal = (float)123.45;
		System.out.println("My Salary = " + sal);
		
		double data = 123.45D;
		System.out.println(data);
		
		System.out.println(10.0f/3.0f);
		System.out.println(10.0/3.0);
		
		System.out.println(Integer.toHexString(65));
	}
}