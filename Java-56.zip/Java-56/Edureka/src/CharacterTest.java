
public class CharacterTest {

	public static void main(String[] args) {
		char c = 'A';
		System.out.println(c);
		
		c = 65;
		System.out.println(c);
		
		c = '\u0041';
		System.out.println(c);
		
		c = '\u4eca'; //is a Japanese character
		System.out.println(c);	
		
		c = '\u0906';
		System.out.println(c);
	}

}
