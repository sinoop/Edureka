
public class First {

	public static void main(String[] args) {
		System.out.println("Welome to Java @ edureka");
		System.out.print("by");
		System.out.println("team @ edureka");
		MethodTest.sayHello();
	}
}