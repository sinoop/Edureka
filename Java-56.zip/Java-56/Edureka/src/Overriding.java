class A{
	int x=10;
	A(int n){
		System.out.println("Inside A constructor");
	}
	void display() {
		System.out.println("Inside display of class A");
	}
}

class B extends A{
	int x=20;
	B(){
		super(2);
		System.out.println("Inside B constructor");
	}
	void test() {
		System.out.println("testing");
	}
	void display() {
		System.out.println("Inside display of class B");
		super.display();
		System.out.println(x+" | "+super.x);
		this.test();
	}	
}

public class Overriding {

	public static void main(String[] args) {
		B obj = new B();
		//obj.display();
	}

}
