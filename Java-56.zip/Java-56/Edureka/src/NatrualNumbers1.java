
public class NatrualNumbers1 {

	public static void main(String[] args) {
		System.out.println("First 10 Natural Numbers are");
		int n=1;
		while(n < 11) {
			System.out.println(n);
			n=n+1;
		}
	}

}
