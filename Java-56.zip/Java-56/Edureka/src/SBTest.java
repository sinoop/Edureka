
public class SBTest {

	public static void main(String[] args) {
		StringBuffer sb = new StringBuffer();
		System.out.println(sb+" |Size="+sb.length()+" | Capacity="+sb.capacity());
		
		sb.append("edureka");
		System.out.println(sb+" |Size="+sb.length()+" | Capacity="+sb.capacity());
		
		sb.append("edureka");
		System.out.println(sb+" |Size="+sb.length()+" | Capacity="+sb.capacity());
		
		sb.insert(0, "EDU");
		System.out.println(sb+" |Size="+sb.length()+" | Capacity="+sb.capacity());
		
		StringBuffer sb1 = new StringBuffer("EDU");
		System.out.println(sb1+" |Size="+sb1.length()+" | Capacity="+sb1.capacity());		
		StringBuffer sb2 = new StringBuffer(80);
		System.out.println(sb2+" |Size="+sb2.length()+" | Capacity="+sb2.capacity());
		
		System.out.println(sb.reverse());
		System.out.println(sb);
		System.out.println(sb.toString().toUpperCase());
		
	}

}
