
public class ArrayTest1 {

	public static void main(String[] args) {
		//Initializing an Array
		int[] marks = {95,98,75,61,82};
		System.out.println("No of Subjects = " + marks.length);
		
		for(int i=0;i<marks.length;i++) {
			System.out.println("Subject-"+(i+1)+" = "+marks[i]);
		}
		
		System.out.print("Marks Obtained :  ");
		//using extended for loop
		for(int mark : marks) {
			System.out.print(mark + " | ");
		}
		System.out.println();
		System.out.println(marks[5]);// java.lang.ArrayIndexOutOfBoundsException
	}
}
