
public class OperatorTest1 {

	public static void main(String[] args) {
		System.out.println(10/3);//3
		System.out.println(10%3);//1
		
		System.out.println(-10%3);//-1
		System.out.println(10%-3);//1
		System.out.println(-10%-3);//-1
		
		System.out.println(10.0/0); //Infinity
		System.out.println(-10.0/0); //-Infinity
		System.out.println(10/0);
	}
}