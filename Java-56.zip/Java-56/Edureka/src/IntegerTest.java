
public class IntegerTest {

	public static void main(String[] args) {
		byte b = 127;
		System.out.println(b);
		
		long pop = 9999899451L;
		System.out.println("World Population = " + pop);
		int n = (int)12L; //explicit typecasting
		System.out.println(n);
	}
}
