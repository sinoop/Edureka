
public class BooleanTest {

	public static void main(String[] args) {
		boolean result = false;
		int x=101,y=20;
		result = x > y;
		System.out.println(result);
	}

}
