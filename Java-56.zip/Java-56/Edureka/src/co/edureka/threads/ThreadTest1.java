package co.edureka.threads;
class MyTask1 implements Runnable{
	public void run() {
		Thread t = Thread.currentThread();
		System.out.println(t);
	}
}

public class ThreadTest1 {

	public static void main(String[] args) {
		System.out.println("No of Active Threads = "+Thread.activeCount());
		Thread t = Thread.currentThread();
		System.out.println(t);
		
		MyTask1 tsk1 = new MyTask1();
		//create a Thread
		Thread ct = new Thread(tsk1);
		//making it as a Runnable Thread
		ct.start(); 
		
		System.out.println("No of Active Threads = "+Thread.activeCount());
	}
}
