package co.edureka.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class BatchExec {

	public static void main(String[] args) throws Exception{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "java56", "password");		 
		Statement st = con.createStatement();
		
		con.setAutoCommit(false);
		
		st.addBatch("insert into emp values(101,'Sunil',123.45)");
		st.addBatch("insert into emp values(102,'Anil',223.45)");
		st.addBatch("insert into emp values(101,'Rinil',323.45)");
		st.addBatch("update emp set sal=333.33");
		
		try {
			int[] rows = st.executeBatch();
			for(int x : rows) {
				System.out.println("rows affected : "+x);
			}
			con.commit();
		}
		catch(Exception e) {
			System.out.println(e.toString());
			con.rollback();
		}
		
		st.close();
		con.close();
	}
}
