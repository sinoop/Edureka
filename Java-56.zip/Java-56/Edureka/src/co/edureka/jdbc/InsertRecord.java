package co.edureka.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class InsertRecord {

	public static void main(String[] args) throws Exception {
		/*
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/edureka", "java56", "password");
		*/
		Connection con = ConnectionFactory.getDBConnection();
		
		Statement st = con.createStatement();
		
		//String sql = "insert into emp values(101,'Sunil',123.45)";
		String sql = "insert into emp(empno, ename, sal) values (102,'edureka',234.34),(103,'Praveen',345.23),(104,'Pankaj',456.12)";
		try {
			int rows_affected = st.executeUpdate(sql);
			System.out.println("Employees Affected : "+rows_affected);
		}
		catch(Exception e) {
			System.out.println("ERROR: "+e.getMessage());
		}
		st.close();
		ConnectionFactory.close();		
	}
}
