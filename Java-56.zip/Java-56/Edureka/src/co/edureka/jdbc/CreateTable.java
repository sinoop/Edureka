package co.edureka.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CreateTable {

	public static void main(String[] args) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/edureka", "java56", "password");
		Statement st = con.createStatement();
		
		String sql = "create table emp(empno int(5), ename varchar(25), sal float(10,2), primary key(empno))";
		
		try {
			st.execute(sql);
			System.out.println("DB Table created");
		}
		catch(Exception e) {
			System.out.println("ERROR: "+e.getMessage());
		}
		st.close();
		con.close();
	}
}