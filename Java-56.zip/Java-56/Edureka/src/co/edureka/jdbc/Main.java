package co.edureka.jdbc;

import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws Exception{
		EmployeeDAO dao = EmployeeDAOFactory.getEmployeeDAO();
		//EmployeeDAO dao = new EmployeeDAOImpl();
		/*
		//insert a record
		Employee emp = new Employee(105,"Sanjay",123.45f);
		dao.saveEmp(emp);
		*/
		/*
		//update a record
		Employee emp = new Employee(101,"Sunil Joseph",444.44f);
		dao.updateEmp(emp);
		*/
		/*
		Scanner sc = new Scanner(System.in);
		System.out.print("enter employee no : ");
		int eno = sc.nextInt();
		dao.deleteEmp(eno);
		*/

		Scanner sc = new Scanner(System.in);
		System.out.print("enter employee no : ");
		int eno = sc.nextInt();
		Employee emp1 = dao.searchEmployee(eno);
		if(emp1!=null)
			System.out.println(emp1);
		else
			System.out.println("No matching employee found!");
		System.out.println("--------------------------");

		List<Employee> emps = dao.getEmployees();
		for(Employee emp : emps) {
			System.out.println(emp);
			Thread.sleep(1000);
		}
	}
}
