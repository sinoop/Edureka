package co.edureka.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class PreparedTest {

	public static void main(String[] args)throws Exception {
		Connection con = ConnectionFactory.getDBConnection();
		PreparedStatement pst = con.prepareStatement("insert into emp values(?,?,?)");
		
		pst.setInt(1, 106);
		pst.setString(2, "Pankaj");
		pst.setFloat(3, 123.45f);
		int n = pst.executeUpdate();
		System.out.println("employee saved - "+n);
		pst.clearParameters();
		
		pst.setInt(1, 107);
		pst.setString(2, "Praveen");
		pst.setFloat(3, 123.45f);
		n = pst.executeUpdate();
		System.out.println("employee saved - "+n);
		pst.clearParameters();
		
		pst.close();
		con.close();
	}
}
