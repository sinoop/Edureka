package co.edureka;
//static imports
import static java.lang.Math.*;
import static java.lang.System.out;

public class MathTest {

	public static void main(String[] args) {
		out.println(E);
		out.println(PI);
		out.println(sqrt(25));
		out.println(min(10, 20));
		out.println(sin(0));
		out.println(cos(0));
		out.println(pow(5, 3));
		System.out.println(floor(10.9));//10.0
		System.out.println(ceil(10.1));//11.0
	}

}
