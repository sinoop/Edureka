package co.edureka.xml;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ReadXmlDom {

	public static void main(String[] args) throws Exception {
		 DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		 DocumentBuilder parser = factory.newDocumentBuilder();
		 File file = new File("src/co/edureka/xml/staff.xml");
		 if(file.exists()) {
			Document doc = parser.parse(file);
			Element root = doc.getDocumentElement();
			System.out.println("Root Element = "+root.getNodeName());
			
			NodeList staff_list = root.getElementsByTagName("staff");
			System.out.println("No of Staffs = "+staff_list.getLength());
			System.out.println("------------------------------------");
			
			for(int i=0;i<staff_list.getLength();i++) {
				Node node = staff_list.item(i);
				if(node.getNodeType() == Node.ELEMENT_NODE) {
					Element staff = (Element)node;
					System.out.println("STAFF ID = "+staff.getAttribute("id"));
					System.out.println("First Name : "+staff.getElementsByTagName("firstname").item(0).getTextContent());
					System.out.println("Last  Name : "+staff.getElementsByTagName("lastname").item(0).getTextContent());
					System.out.println("Nick  Name : "+staff.getElementsByTagName("nickname").item(0).getTextContent());
					System.out.println("Salary     : "+staff.getElementsByTagName("salary").item(0).getTextContent());
					System.out.println("--------------------------------");
				}
			}
		 }
		 else {
			 System.out.println("XML document is not available for parsing!");
		 }
		 
	}

}
