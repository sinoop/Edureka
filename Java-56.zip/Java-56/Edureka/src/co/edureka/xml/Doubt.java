package co.edureka.xml;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Doubt {

	public static void main(String[] args) throws Exception {
		 DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		 DocumentBuilder parser = factory.newDocumentBuilder();
		 File file = new File("src/co/edureka/xml/staff.xml");
		 if(file.exists()) {
			Document doc = parser.parse(file);
			Element root = doc.getDocumentElement();
			System.out.println("Root Element = "+root.getNodeName());
			
			NodeList children = root.getChildNodes();
			System.out.println("No of child elements for root element - "+root.getNodeName()+"= "+children.getLength());
			
			for(int i=0;i<children.getLength();i++) {
				Node node = children.item(i);
				if(node.getNodeType()==Node.ELEMENT_NODE) {
					System.out.println(node.getNodeName());
				}
			}

		 }
		 else {
			 System.out.println("XML document is not available for parsing!");
		 }

	}

}
