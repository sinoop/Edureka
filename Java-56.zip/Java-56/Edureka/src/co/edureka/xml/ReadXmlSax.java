package co.edureka.xml;

import java.io.File;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class ReadXmlSax {

	public static void main(String[] args) throws Exception {
		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser parser = factory.newSAXParser();

		File file = new File("src/co/edureka/xml/staff.xml");
		MyHandler handler = new MyHandler();

		parser.parse(file, handler);
	}
}

class MyHandler extends DefaultHandler {
	boolean fname = false;
	boolean lname = false;
	boolean nname = false;
	boolean salary = false;

	@Override
	public void startDocument() throws SAXException {
		System.out.println("XML document parsing started");
	}

	@Override
	public void endDocument() throws SAXException {
		System.out.println("XML document parsing completed");
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		System.out.println("Start Element - "+qName);
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		System.out.println("End Element - "+qName);
	}

	public void characters(char[] ch, int start, int length) throws SAXException {
		System.out.println("** Data found ");
	}
}
