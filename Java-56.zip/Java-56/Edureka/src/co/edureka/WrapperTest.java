package co.edureka;

public class WrapperTest {

	public static void main(String[] args) {
		Integer i1 = new Integer(25);
		Integer i2 = new Integer("25");
		Integer i3 = Integer.valueOf(25);
		Integer i4 = Integer.valueOf("25");
		
		System.out.println(i1+" | "+i2+" | "+i3+" | "+i4);
		
		Integer n = new Integer(25);
		byte b = n.byteValue();
		short s = n.shortValue();
		int n1 = n.shortValue();
		long l = n.longValue();
		float f = n.floatValue();
		double d = n.doubleValue();
		System.out.println(b+" | "+s+" | "+n1+" | "+l+" | "+f+" | "+d);
		
		int x1 = 26;
		Integer x2 = x1; //boxing
		int x3 = x2; //un-boxing
		System.out.println(x1+" | "+x2+" | "+x3);
	}
}
