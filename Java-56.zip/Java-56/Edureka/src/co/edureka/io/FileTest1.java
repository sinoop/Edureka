package co.edureka.io;

import java.io.File;

public class FileTest1 {

	public static void main(String[] args) {
		File file = new File("src/First.java");
		System.out.println("Is Exists - "+file.exists());
		
		if(file.exists()) {
			System.out.println("Is File - "+file.isFile());
			System.out.println("Is Directory - "+file.isDirectory());
			System.out.println("Name - "+file.getName());
			System.out.println("Path - "+file.getPath());
			System.out.println("Parent - "+file.getParent());
			System.out.println("Is Absolute Path - "+file.isAbsolute());
			System.out.println("Absolute Path - "+file.getAbsolutePath());
			System.out.println("Size - "+file.length()+" bytes");
			System.out.println("Can Read - "+file.canRead());
			System.out.println("Can Write - "+file.canWrite());
			System.out.println("Is Hidden - "+file.isHidden());
			
			long mtime = file.lastModified();
			java.util.Date mdate = new java.util.Date(mtime);
			System.out.println("First.java is modified on - "+mdate);
		}
		
		File ff= new File("D:/Java-56/sunil");
		if(!ff.exists() || !ff.isDirectory())
		{
			ff.mkdir();
		}
	}
}