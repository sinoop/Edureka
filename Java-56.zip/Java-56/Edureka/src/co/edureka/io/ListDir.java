package co.edureka.io;

import java.io.File;

public class ListDir {

	public static void main(String[] args) throws Exception{
		File dir = new File("D:/Java-56");
		if(dir.isDirectory()) {
			String[] fnames = dir.list();
			for(String fname : fnames) {
				//if(fname.endsWith(".java")) {
				if(fname.startsWith("I") && fname.endsWith(".java")) {
					System.out.println(fname);
					Thread.sleep(200);
				}
			}
		}
	}
}
