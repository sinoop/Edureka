package co.edureka.io;

import java.io.FileOutputStream;

public class FileWrite {

	public static void main(String[] args) throws Exception {
		FileOutputStream fout = new FileOutputStream("src/Alphabets.txt");
		//FileOutputStream fout = new FileOutputStream("src/Alphabets.txt",true);//appending mode
		
		String str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		byte[] data = str.getBytes(); // convert String a sequence of bytes
		fout.write(data);
		
		System.out.println("file created");
		fout.close();
	}
}