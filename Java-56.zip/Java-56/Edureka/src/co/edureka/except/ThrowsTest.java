package co.edureka.except;
class Sunil{
	void method1() throws InterruptedException {
		System.out.println("Logic");
	}
}
public class ThrowsTest {
	public static void main(String[] args) throws InterruptedException{
		Sunil obj = new Sunil();
		//try {
			obj.method1();
		//}catch(Exception e) {}
	}
}
