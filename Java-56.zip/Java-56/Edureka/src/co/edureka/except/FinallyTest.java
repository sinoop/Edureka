package co.edureka.except;

import java.util.Scanner;

public class FinallyTest {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter two numbers:");
		try {
			int x = sc.nextInt();
			int y = sc.nextInt();
			int z = x/y;
			System.out.println("result = "+z);
		}
		catch(ArithmeticException e) {
			System.out.println("ERROR: "+e.getMessage());
		}
		finally {
			System.out.println("Application Designed & Developed by");
			System.out.println("team @ edureka");
		}
		System.out.println("application completed");
	}
}