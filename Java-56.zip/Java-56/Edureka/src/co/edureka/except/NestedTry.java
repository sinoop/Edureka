package co.edureka.except;

public class NestedTry {
	public static void main(String[] args) {		
		int[] data= {25,5,0,12};
		try {
			try {
				int x = data[0]/data[2];
				System.out.println("result = "+x);
			}
			catch(ArithmeticException e) {
				System.out.println("Error : "+e.getMessage());
			}
			data[4]=24;
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("ERROR: Invalid Array Index : "+e.getMessage());
		}
	}	
}