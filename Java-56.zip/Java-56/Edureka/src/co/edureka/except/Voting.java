package co.edureka.except;

import java.util.Scanner;

public class Voting {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		try {
			System.out.print("enter the age of voter: ");
			int age = sc.nextInt();
			if(age < 18)
				throw new InvalidAgeException("age should be >= 18");
			System.out.println("Done !");
		}
		catch(Exception e) {
			System.out.println("Message : "+e.getMessage());
			System.out.println(e);
		}
		System.out.println("Next Voter");
	}

}
