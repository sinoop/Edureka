package co.edureka.except;

public class Except3 {

	public static void main(String[] args) {
		//String name = "Sunil";
		String name = null;
		System.out.println(name);
		System.out.println("Size = "+ name.length());
	}
}