package co.edureka.except;

public class ThrowTest {
	static void calc(int x, int y) {
		if(y==0)
			//throw new ArithmeticException();
			throw new ArithmeticException("cannot divide by zero");
		int res = x / y;
		System.out.println("Result = "+res);
	}
	public static void main(String[] args) {
		try {
			calc(10,0);
		}
		catch(Exception e) {
			System.out.println("Message: "+e.getMessage());
			System.out.println(e);
			e.printStackTrace();
		}
	}
}