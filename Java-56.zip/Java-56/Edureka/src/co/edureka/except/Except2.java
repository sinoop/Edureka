package co.edureka.except;

public class Except2 {

	public static void main(String[] args) {
		String data = "A";
		int n = Integer.parseInt(data);
		System.out.println(n);
	}

}
