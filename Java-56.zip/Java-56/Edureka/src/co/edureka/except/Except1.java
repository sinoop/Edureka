package co.edureka.except;
import java.util.Scanner;

public class Except1 {
	void calc() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter 2 numbers:");
		int x = sc.nextInt();
		int y = sc.nextInt();
		int res = x/y;
		System.out.println("Result = "+res);				
	}
	public static void main(String[] args) {
		Except1 obj = new Except1();
		obj.calc();
		System.out.println("application completed");
	}
}
