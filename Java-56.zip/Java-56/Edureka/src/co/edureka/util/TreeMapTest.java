package co.edureka.util;

import java.util.TreeMap;

public class TreeMapTest {

	public static void main(String[] args) {
		TreeMap<String, Float> bank = new TreeMap<>();
		
		bank.put("Sunil", 15000.5f);
		bank.put("Anil", 25000.0f);
		bank.put("Rahul", 45500.5f);
		bank.put("Praveen", 45874.5f);
		bank.put("Sunil", 11500.5f);
		//bank.put("Ajay", null);
		bank.put(null, 123.5f);
		System.out.println(bank);
	}

}
