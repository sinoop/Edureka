package co.edureka.util;

import java.util.Vector;

public class VectorTest {

	public static void main(String[] args) {
		//Vector<Integer> v = new Vector<Integer>();
		//Vector<Integer> v = new Vector<Integer>(5);
		Vector<Integer> v = new Vector<Integer>(5,3);//initial capacity, capacity increment
		
		System.out.println(v+" |Size="+v.size()+" |Capacity="+v.capacity());
		
		for(int i=11;i<=20;i++) {
			v.add(i);
		}
		System.out.println(v+" |Size="+v.size()+" |Capacity="+v.capacity());
		v.ensureCapacity(100);
		v.add(21);
		System.out.println(v+" |Size="+v.size()+" |Capacity="+v.capacity());
	}
}
