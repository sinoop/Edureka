package co.edureka.util;

import java.util.ArrayList;

public class ArrayListTest {

	public static void main(String[] args) {
		ArrayList<String> names = new ArrayList<String>();
		System.out.println(names+" | Size="+names.size());
		
		names.add("Anuradha");
		names.add("Chandrasekhar");
		names.add("Desta");
		names.add("Dipanjan");
		names.add("Mustafa");
		names.add("Anuradha");
		
		System.out.println(names+" | Size="+names.size());
		names.add(1,"Oladipupo");
		names.set(3,"Rani");
		System.out.println(names+" | Size="+names.size());
		
		System.out.println("Person in index 1 : "+names.get(1));
		System.out.println("Index of Anuradha = "+names.indexOf("Anuradha"));
		System.out.println("Last Index of Anuradha = "+names.lastIndexOf("Anuradha"));
		
		names.remove(0);
		System.out.println(names+" | Size="+names.size());
		System.out.println(names.contains("Rani"));
	}
}