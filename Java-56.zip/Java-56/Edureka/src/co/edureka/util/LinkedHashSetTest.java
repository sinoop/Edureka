package co.edureka.util;

import java.util.LinkedHashSet;

public class LinkedHashSetTest {

	public static void main(String[] args) {
		LinkedHashSet<String> names = new LinkedHashSet<>();
		names.add("Anil");
		names.add("Rahul");
		names.add("Praveen");
		names.add("Pankaj");
		names.add("Arun");
		names.add("Anil");
		names.add(null);
		System.out.println(names + "| Size ="+names.size());				
	}

}
