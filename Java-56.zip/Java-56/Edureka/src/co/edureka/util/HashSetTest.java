package co.edureka.util;

import java.util.HashSet;

public class HashSetTest {

	public static void main(String[] args) {
		HashSet<String> names = new HashSet<>();
		names.add("Anil");
		names.add("Rahul");
		names.add("Praveen");
		names.add("Pankaj");
		names.add("Arun");
		names.add("Anil");
		names.add(null);
		System.out.println(names + "| Size ="+names.size());		
	}
}
