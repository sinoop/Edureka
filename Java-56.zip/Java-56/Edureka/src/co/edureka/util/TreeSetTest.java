package co.edureka.util;

import java.util.Comparator;
import java.util.TreeSet;

public class TreeSetTest {

	public static void main(String[] args) {
		TreeSet<String> names = new TreeSet<>(new MyComparator());
		names.add("Anil");
		names.add("Rahul");
		names.add("Praveen");
		names.add("Pankaj");
		names.add("Arun");
		names.add("Anil");		
		System.out.println(names + "| Size ="+names.size());
	}
}

class MyComparator implements Comparator<String>{
	public int compare(String s1, String s2) {	
		//System.out.println(s1+" | "+s2);
		if(s1.compareTo(s2) > 0)
			return -1;
		else if(s1.compareTo(s2) < 0)
			return 1;
		else
			return 0;
	}
}
