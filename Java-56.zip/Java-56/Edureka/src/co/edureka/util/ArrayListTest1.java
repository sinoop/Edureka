package co.edureka.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;

public class ArrayListTest1 {

	public static void main(String[] args) throws Exception{
		ArrayList<Integer> al = new ArrayList<>();
		for(int i=11;i<=16;i++) {
			al.add(i); //boxing
		}
		System.out.println(al);
		
		System.out.println("<<<1) using a normal for loop .. only for List");
		for(int i=0;i<al.size();i++) {
			Integer n = al.get(i);
			System.out.print(n+"\t");
		}
		System.out.println();
		Thread.sleep(1000);
		
		System.out.println("<<<2) using an extended for loop");
		for(Integer n : al) {			
			System.out.print(n+"\t");
		}
		System.out.println();
		Thread.sleep(1000);	
		
		System.out.println("<<<3) using java.util.Iterator");
		Iterator<Integer> it = al.iterator();
		while(it.hasNext()) {
			Integer n = it.next();
			System.out.print(n+"\t");
		}
		System.out.println();
		Thread.sleep(1000);	
		
		System.out.println("<<<4) using java.util.ListIterator .. for List");
		ListIterator<Integer> lit = al.listIterator();
		while(lit.hasNext()) {
			Integer n = lit.next();
			System.out.print(n+"\t");
		}
		System.out.println();
		Thread.sleep(1000);	
		
		while(lit.hasPrevious()) {
			Integer n = lit.previous();
			System.out.print(n+"\t");
		}
		System.out.println();
		Thread.sleep(1000);	
		
		System.out.println("<<<5) using java.util.Enumeration");
		Enumeration<Integer> en = Collections.enumeration(al);
		while(en.hasMoreElements()) {
			Integer n = en.nextElement();
			System.out.print(n+"\t");
		}
		System.out.println();
		Thread.sleep(1000);
		
		System.out.println("------------------------------");
		System.out.println(al);

		Iterator<Integer> it1 = al.iterator();
		while(it1.hasNext()) {
			Integer n = it1.next();
			System.out.print(n+"\t");
			it1.remove();
		}
		System.out.println();
		Thread.sleep(1000);
		System.out.println(al);
	}
}