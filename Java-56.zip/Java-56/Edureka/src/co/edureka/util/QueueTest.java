package co.edureka.util;

import java.util.PriorityQueue;

public class QueueTest {

	public static void main(String[] args) {
		PriorityQueue<String> pq = new PriorityQueue<String>();
		pq.add("Sunil");
		System.out.println(pq);
		//System.out.println(pq.poll());
		//System.out.println(pq.remove());
		System.out.println(pq.peek());
		System.out.println(pq);
	}

}
