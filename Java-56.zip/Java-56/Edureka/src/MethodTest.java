public class MethodTest {
	static int addNum(int a, int b) {
		return a+b;
	}
	public static void main(String[] args) {
		sayHello();
		sayHello();
		sayHello();
		sayHello("edureka");
		System.out.println("Sum = "+addNum(11,22));
	}

	static void sayHello() {
		System.out.println("Hello, Guest");
	}

	static void sayHello(String name) {
		System.out.println("Hello, " + name);
	}
}