package org.tempuri;

public class Main {

	public static void main(String[] args) throws Exception{
		CalculatorLocator locator = new CalculatorLocator(); 
		CalculatorSoap obj = locator.getCalculatorSoap();
		System.out.println("Sum = "+obj.add(5, 6));
		System.out.println("Product = "+obj.multiply(5, 6));
	}
}
