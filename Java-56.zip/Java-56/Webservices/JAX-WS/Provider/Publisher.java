package co.edureka;  

import javax.xml.ws.Endpoint;  

public class Publisher
{  
public static void main(String[] args) 
{  
 NumsImpl nums = new NumsImpl();
 Endpoint.publish("http://localhost:8082/ws/nums", nums); 
 System.out.println("Webservice is ready...");
}  
}  