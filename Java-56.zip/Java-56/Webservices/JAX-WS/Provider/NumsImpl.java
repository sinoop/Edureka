package co.edureka;

import javax.jws.WebService;  

@WebService(endpointInterface="co.edureka.Nums")

public class NumsImpl implements Nums
{
 public int addNum(int x, int y){
	 System.out.println("- add method is accessed");
	 return x+y;
 }
 public float subNum(float a, float b){
	 System.out.println("- sub method is accessed");
	 return a-b;
 }
}
