import co.edureka.*;
class Main 
{
	public static void main(String[] args) throws Exception
	{
	  NumsImplService service = new NumsImplService();
	  Nums obj = service.getNumsImplPort();
	  System.out.println("Sum = "+obj.addNum(11,22));
	  System.out.println("Diff = "+obj.subNum(11,22));
	}
}
