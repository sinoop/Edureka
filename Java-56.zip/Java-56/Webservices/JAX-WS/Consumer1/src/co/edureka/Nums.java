/**
 * Nums.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package co.edureka;

public interface Nums extends java.rmi.Remote {
    public float subNum(float a, float b) throws java.rmi.RemoteException;
    public int addNum(int x, int y) throws java.rmi.RemoteException;
}
