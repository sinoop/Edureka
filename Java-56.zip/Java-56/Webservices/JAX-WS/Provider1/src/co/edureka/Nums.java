package co.edureka;

public class Nums {
 public int addNum(int x, int y) {
	 return x+y;
 }
 public float subNum(float a, float b) {
	 return a-b;
 }
}
