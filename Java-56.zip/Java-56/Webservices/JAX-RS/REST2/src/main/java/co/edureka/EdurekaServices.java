package co.edureka;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

@Path("/edureka")
public class EdurekaServices {
	/*
	 @GET
	 @Produces("text/html")
	 public Response localService() 
	 {
	    String output = "<h2>Local Customer Service Center</h2>";
	    return Response.status(200).entity(output).build();
	 }*/

	 @GET
	 @Path("/nri")
	 @Produces("text/html")
	 public Response nriService() {
	   String output = "<h2>NRI Customer Service Center</h2>";
	   return Response.status(200).entity(output).build();
	 } 
	 
	 @GET
	 @Path("{name}/{course}")
	 @Produces("text/html")
	 public Response enquiry(@PathParam("name") String name, @PathParam("course") String course) {        
	     String output = "<h2>Customer Name - "+name+"<br>Course Name - "+course+"</h2>";
	     return Response.status(200).entity(output).build(); 
	 }
	 
	 @GET
	 @Produces("text/html")
	 public Response enquiry1(@QueryParam("name") String name, @QueryParam("course") String crs) {
	   String output = "<h2>Customer Name : "+name+"<br> Course Name : "+crs+"</h2>";
	   return Response.status(200).entity(output).build(); 
	 }
	 
	 @POST
	 @Path("/registerCustomer")
	 @Produces("text/html")
	 public Response register(@FormParam("name") String name, @FormParam("age") String age, @FormParam("addr") String address) 
	 {
	   String output = "<div style=color:red;font-size:35px;>Registration Success::<br> Name - <u>"+name+"</u><br><br>Age - <u>"+age+"</u><br><br>Address - <u>"+address+"</u><hr></div>";
	   return Response.status(200).entity(output).build();
	 }
}
