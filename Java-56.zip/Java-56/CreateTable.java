import java.sql.*;
class CreateTable 
{
	public static void main(String[] args) throws Exception
	{
	  System.out.println("<<<1. Initializing the Oracle JDBC Driver");
	  Class.forName("oracle.jdbc.driver.OracleDriver");

	  System.out.println("<<<2. Connect to Oracle DB Server");
	  Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "java56", "password");
	  System.out.println("<<< Connected to Oracle DB");

	  System.out.println("<<<3. Create an object for passing SQL queries to DB");
	  Statement st = con.createStatement();

	  System.out.println("<<<4. Pass the SQL to create a DB table-emp");

	  String sql = "create table emp(empno number(5) primary key, ename varchar(25), sal number(10,2))";

	  try{
		  st.execute(sql);
		  System.out.println("DB Created created!");
	  }
	  catch(Exception e){
		  System.out.println("ERROR: "+e.toString());
	  }

	  System.out.println("<<<5. Close the connection with DB");
	  st.close();
	  con.close();
	}
}
