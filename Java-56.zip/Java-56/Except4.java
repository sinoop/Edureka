class Except4 
{
	public static void main(String[] args) 
	{
		try{
			int x = Integer.parseInt(args[0]);
			int y = Integer.parseInt(args[1]);
			int res = x/y;
			System.out.println("Result = "+res);
		}
		catch(Exception e){
			System.out.println("ERROR: Exception Occured");
			System.out.println("Message: "+e.getMessage());
			System.out.println(e.toString());//object type : message of exception
			e.printStackTrace();//toString()+call stack
		}

		System.out.println("application completed");
	}
}