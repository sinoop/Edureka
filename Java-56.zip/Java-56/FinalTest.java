final class A{
	//final A()//CE modifier final not allowed here{}
	final void display(){}
}
class B extends A{ //CE
	void display(){}
}

class FinalTest 
{
	final int age; //blank final variable
	FinalTest(){
		age=25;
	}
	public static void main(String[] args) 
	{
		final int n = 12;
		System.out.println(n);
		//n = 13;//CE cannot assign a value to final variable n
		System.out.println(n);
	}
}
