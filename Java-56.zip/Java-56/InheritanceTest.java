class Parent{
	int md1 = 12;
	void method1(){
		System.out.println("Inside Parent class");
	}
}

class Child extends Parent{
	int md2 = 24;
	void method2(){
		System.out.println("Child Class");
	}
}

class InheritanceTest 
{
	public static void main(String[] args) 
	{
		Child obj = new Child();
		System.out.println(obj.md1+" | "+obj.md2);
		obj.method1();
		obj.method2();
	}
}
