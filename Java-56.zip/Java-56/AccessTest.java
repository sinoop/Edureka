class A{
	private int n = 10;
	protected void display(){	}
}
class B extends A{
	protected void display(){}
}

class AccessTest 
{
	public static void main(String[] args) 
	{
		A obj = new A();
		System.out.println(obj.n);
	}
}
