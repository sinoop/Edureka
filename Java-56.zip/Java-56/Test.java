class Edureka{
	static{
		System.out.println("Inside static block of Edureka");
	}
}

class Test 
{
	public static void main(String[] args) throws Exception
	{
		Class.forName("Edureka");
	}
}
