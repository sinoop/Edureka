class A{
	void display(){
		System.out.println("Class A Method");
	}
}

class B extends A{
	void display(){
		System.out.println("Class B Method");
	}
}

class Polymorphism {
	public static void main(String[] args) 	{
		//A obj = new A();
		//B obj = new B();
		A obj = new B();
		obj.display();
	}
}
