abstract class Shape{
	private String color;
	Shape(String color){
		this.color=color;
	}
	public String getColor(){
		return color;
	}
	public void setColor(String color){
		this.color=color;
	}
	abstract void area();
}

class Rectangle extends Shape{
	private int length, breadth;
	Rectangle(String color, int len, int bre){
		super(color);
		this.length = len;
		this.breadth = bre;
	}
	void area(){
		System.out.println("Area = "+(length*breadth));
	}
}

class AbsTest 
{
	public static void main(String[] args) 
	{
		Shape shape = new Rectangle("Yellow",5,3);
		System.out.println("Color = "+shape.getColor());
		shape.area();
	}
}
