class InterTest implements Inter1 
{
	public void addNum(int a, int b){
		System.out.println("Sum = "+(a+b));
	}

	public void subNum(int a, int b){
		System.out.println("Diff = "+(a-b));
	}

	public static void main(String[] args) 
	{
		Inter1 obj = new InterTest();
		System.out.println(obj.x+" | "+obj.y);
		System.out.println(Inter1.x+" | "+Inter1.y);
		//Inter1.x = 10;//CE
		obj.addNum(10,20);
		obj.subNum(20,10);
	}
}
