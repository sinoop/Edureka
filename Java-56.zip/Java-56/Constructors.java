class Employee 
{
	int empno;
	String ename;
	float sal;
    /*constructor with 0 parameters*/
	Employee(){
      System.out.println("****");
      empno = 101;
	  ename = "edureka";
	  sal = 123.45f;
	}
	void getDetails(){
      System.out.println(empno + " | "+ename+" | "+sal);
	}
}//Employee

class Constructors{
	public static void main(String[] args) 
	{
		Employee emp1 = new Employee();
		Employee emp2 = new Employee();
		Employee emp3 = new Employee();

		emp1.getDetails();
		emp2.getDetails();	
		emp3.getDetails();
	}
}
