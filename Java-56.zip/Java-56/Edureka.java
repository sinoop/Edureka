/*
Program to display a welcome message
Author : Sunil @ edureka
Date : 29th October 2017
*/

public class First
{
  public static void main(String[] args)
  {
    System.out.println("Welcome to Java @ edureka");
  }
}