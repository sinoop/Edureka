class Employee 
{
	int empno;
	String ename;
	float sal;
   
	Employee(){}
	Employee(int empno, String ename){  
      this.empno = empno;
	  this.ename = ename;
	}
	Employee(int a, String b, float c){
	 /*	
      this.empno = a;
	  ename = b;
	 */
	  this(a,b);
	  sal = c;
	}
	void getDetails(){
      System.out.println(empno + " | "+ename+" | "+this.sal);
	}
}//Employee

class OverloadingConstructors{
	public static void main(String[] args) 
	{
		Employee emp1 = new Employee();
		Employee emp2 = new Employee(102,"Sunil");
		Employee emp3 = new Employee(103,"Sanjay",234.45f);

		emp1.getDetails();
		emp2.getDetails();	
		emp3.getDetails();
	}
}
