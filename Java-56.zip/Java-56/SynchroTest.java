class Table{
	//void printTable(int n){
	synchronized void printTable(int n){
  	  try{
		for(int i=1;i<=10;i++){
			int p = n * i;
			System.out.println(n+" x "+i+" = "+p);
			Thread.sleep(500);
		}
		System.out.println("--------------------------");
		Thread.sleep(4000);
	  }
	  catch(Exception e){}
	}
}

class MyThread1 extends Thread
{
 Table table;
 MyThread1(Table t){
	 table = t;
 }
 public void run(){
	table.printTable(5);
 }
}

class MyThread2 extends Thread
{
 Table table;
 MyThread2(Table t){
	 table = t;
 }
 public void run(){
	table.printTable(6);
 }
}

class SynchroTest 
{
	public static void main(String[] args) 
	{
		Table table = new Table();
		MyThread1 mt1 = new MyThread1(table);
		MyThread2 mt2 = new MyThread2(table);

		mt1.start();
		mt2.start();
	}
}
