package co.edureka.pack1;

public class PackTest 
{
	public static void main(String[] args) 
	{
		System.out.println("Package Example");
	}
}
