package co.edureka;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		EmployeeDAO dao =(EmployeeDAO)context.getBean("empdao");
		
		Employee emp = new Employee(108,"Spring User",555.55f);
		dao.saveEmp(emp);
		
		Employee emp1 = new Employee(101,"Sunil Joseph",999.99f);
		dao.updateEmp(emp1);
		
		List<Employee> emps = dao.getEmployees();
		for(Employee e : emps) {
			System.out.println(e);
		}
	}
}
