class Main 
{
	public static void main(String[] args) 
	{
		Student st1=new Student();
		Student st2=new Student("edureka");

		st1.sayHello();
		st2.sayHello();
	}
}
