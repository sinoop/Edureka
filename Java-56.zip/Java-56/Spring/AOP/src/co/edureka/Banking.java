package co.edureka;

public class Banking {
 public void deposit() {	 
	 System.out.println("Core Concern: a generic deposit method");
 }
 public void deposit(String acno, float amt) {
	 System.out.println("Core Concern: depositing amount of Rs:"+amt+" in A/C: "+acno);;
 }
}
