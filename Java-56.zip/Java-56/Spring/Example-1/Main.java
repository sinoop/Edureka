import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

class Main 
{
	public static void main(String[] args) 
	{
		BeanFactory factory = new ClassPathXmlApplicationContext("beans.xml");

		Student st1 = (Student)factory.getBean("stud1");
		st1.sayHello();
		System.out.println();

		Student st2 = factory.getBean("stud2", Student.class);
		st2.sayHello();
		System.out.println();

		Student st3 = factory.getBean("stud2", Student.class);
		st3.sayHello();
		System.out.println();

		Student st4 = factory.getBean("stud2", Student.class);
		st4.sayHello();
	}
}