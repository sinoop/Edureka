package co.edureka;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("context.xml");
		Banking bank = context.getBean("bank", Banking.class);
		bank.deposit();
		bank.deposit("SBI12332",25000f);		
	}
}