package co.edureka;

public class Banking {
	public void deposit() {
		System.out.println("Depositing Amount!");
	}

	public void deposit(String acno, double amt) {
		System.out.println("Depositing amount Rs. " + amt + " in A/C: " + acno);
	}
}