package co.edureka;

import java.util.Date;

public class Logger {
 public void log() {
	 System.out.println("LOG: Going to deposit amount | "+new Date());
 }
 public void notification() {
	 System.out.println("NOTIFY: send information to IT");
 }
}
