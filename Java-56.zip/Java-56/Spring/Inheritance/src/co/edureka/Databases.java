package co.edureka;
import java.util.List;
public class Databases {
  List<String> dbNames;

public List<String> getDbNames() {
	return dbNames;
}

public void setDbNames(List<String> dbNames) {
	this.dbNames = dbNames;
}
  
}
