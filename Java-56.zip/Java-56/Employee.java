class Employee 
{
	int empno;
	String ename;
	float sal;

	void assignDetails(){
      empno = 101;
	  ename = "edureka";
	  sal = 123.45f;
	}
	void getDetails(){
      System.out.println(empno + " | "+ename+" | "+sal);
	}
	public static void main(String[] args) 
	{
		Employee emp = new Employee();
		/*
		emp.empno = 101;
		emp.ename = "edureka";
		emp.sal = 123.45f;
		*/
		emp.assignDetails();
		System.out.println(emp.empno+" | "+emp.ename+" | "+emp.sal);
		emp.getDetails();
	}
}
