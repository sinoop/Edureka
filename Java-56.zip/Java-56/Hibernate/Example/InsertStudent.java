import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;

class InsertStudent 
{
	public static void main(String[] args) 
	{
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml"); //XML Parsing

		SessionFactory sfactory = cfg.buildSessionFactory();
		Session session = sfactory.openSession(); 
	
		Transaction t=session.beginTransaction();

		Student stud=new Student(101,"Sunil","sunil@yahoo.com","9848586878");
		session.save(stud);

		System.out.println("------------------------------------------------");
		
		t.commit(); 
		System.out.println("Student Saved");

		session.close();
		sfactory.close();
	}
}