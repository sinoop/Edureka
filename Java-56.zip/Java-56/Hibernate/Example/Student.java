//POJO class -Student.java
public class Student
{
 private int sid;
 private String sname,email,mobile;

 public Student(){}

 public Student(int sid, String sname, String email, String mobile){
	 this.sid=sid;
	 this.sname=sname;
	 this.email=email;
	 this.mobile=mobile;
 }

 public int getSid(){
	 return this.sid;
 }
 public void setSid(int sid){
	 this.sid=sid;
 }

 public String getSname(){
	 return this.sname;
 }
 public void setSname(String sname){
	 this.sname=sname;
 }

 public String getEmail(){
	 return this.email;
 }
 public void setEmail(String email){
	 this.email=email;
 }

 public String getMobile(){
	 return this.mobile;
 }
 public void setMobile(String mobile){
	 this.mobile=mobile;
 }
}