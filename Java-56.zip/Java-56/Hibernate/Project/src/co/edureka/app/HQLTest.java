package co.edureka.app;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import co.edureka.configs.HibernateUtils;
import co.edureka.domain.Student;

public class HQLTest {

	public static void main(String[] args) throws InterruptedException {
		SessionFactory sf = HibernateUtils.getSessionFactory();
		Session session = sf.openSession();
		
		//String hql = "from co.edureka.domain.Student";
		//Query q = session.createQuery(hql);
		//String hql = "from co.edureka.domain.Student where sname='Sanjay'";
		//String hql = "from co.edureka.domain.Student where studid between ? and ?"; //positional parameters
		String hql = "from co.edureka.domain.Student where studid between :minsid and :maxsid"; //named parameters
		
		TypedQuery<Student> q = session.createQuery(hql);
		//q.setParameter(0, new Integer(101));
		//q.setParameter(1, new Integer(105));
		
		q.setParameter("minsid", new Integer(103));
		q.setParameter("maxsid", new Integer(110));
		
		List<Student> students = q.getResultList();
		for(Student st : students) {
			System.out.println(st);
			Thread.sleep(500);
		}		
		System.out.println("------------------------------");
		
		Transaction tx = session.beginTransaction();
	    TypedQuery up = session.createQuery("update co.edureka.domain.Student set sname=:name where studid=:sid");  
	    up.setParameter("name","Sunil");  
	    up.setParameter("sid",101);  
			      
	    int rows_affected = up.executeUpdate();  
	    System.out.println("No of Students Updated = "+rows_affected);  
		tx.commit();
		
		session.close();
		sf.close();
	}
}
