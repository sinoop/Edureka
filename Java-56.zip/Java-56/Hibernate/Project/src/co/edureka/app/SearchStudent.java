package co.edureka.app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import co.edureka.configs.HibernateUtils;
import co.edureka.domain.Student;

public class SearchStudent {

	public static void main(String[] args) {
		SessionFactory sf = HibernateUtils.getSessionFactory();
		Session session = sf.openSession();
		Student st = new Student();//transient state
		System.out.println(st);
		try {
			session.load(st, new Integer(1015)); //persistent state
			session.evict(st);//detached state
		}
		catch(Exception e) {
		 System.out.println(e);
		}
		System.out.println(st);
		
		session.close();
		sf.close();
	}
}