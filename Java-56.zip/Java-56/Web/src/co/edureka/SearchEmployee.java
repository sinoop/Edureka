package co.edureka;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import org.json.JSONObject; //java-json.jar
import javax.servlet.annotation.WebServlet;

@WebServlet("/search")
public class SearchEmployee extends HttpServlet
{
	private static PreparedStatement pst=null;

	public void init(ServletConfig config) throws ServletException{
		super.init(config);
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/edureka","java56","password");
			pst=con.prepareStatement("select ename,sal from emp where empno=?");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		response.setContentType("application/json");
		PrintWriter out=response.getWriter();
		String eno=request.getParameter("eno");		
		try
		{
			pst.setString(1, eno);
			ResultSet rs=pst.executeQuery();
			if(rs.next()){								
				String name=rs.getString(1);
				String sal=rs.getString(2);
				JSONObject jobj=new JSONObject();
				jobj.put("name",name);
				jobj.put("sal",sal);
				out.println(jobj);
			}
			else{
				out.print("");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		doGet(request, response);
	}
}