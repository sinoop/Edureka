package co.edureka;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
@WebFilter("/welcome")
//@WebFilter("/*")
public class LoginFilter implements Filter {
	public void destroy() {}
	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException
	{
	/*	String uid = request.getParameter("uid");
		String pwd = request.getParameter("pwd");
		if(uid.equals("admin") && pwd.equals("123"))
			chain.doFilter(request, response); // - forward the request to welcome servlet
		else {
			RequestDispatcher rd = request.getRequestDispatcher("Login.html");
			rd.include(request, response);
		}*/
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<p style=text-align:center;font-size:25px;margin-top:100px>");
		out.println("Site is under maintenance! <br><br> Check back @ 00.00AM</p>");
	}

	public void init(FilterConfig fConfig) throws ServletException {}
}
