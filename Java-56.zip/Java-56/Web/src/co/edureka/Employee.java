//Java Bean - POJO (Plain Old Java Object)
package co.edureka;

public class Employee {
 private int empno;
 private String name;
 private float sal;
public int getEmpno() {
	return empno;
}
public void setEmpno(int empno) {
	this.empno = empno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getSal() {
	return sal;
}
public void setSal(float sal) {
	this.sal = sal;
} 
}
