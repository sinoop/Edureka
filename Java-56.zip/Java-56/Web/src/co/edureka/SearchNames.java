package co.edureka;
import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/searchname")
public class SearchNames extends HttpServlet
{
public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
{
 res.setContentType("text/plain");
 PrintWriter out=res.getWriter();
 String[] names={"Aby","British","Cinderella","Diana","Emanuel","Florida","Gunga", "Hedge","Iby","Johan","Krishna","Linda","Nina","Ouseph","Pradeep","Amanda","Rama","Cindrella","David","Eve","Evita","Sunniva","Tove","Unni","Violet","Liza","Elizabeth","Ellen","Wikram","Vicky","Arun","Anand","Abee","Abanda","Aruna","Aparna","Tejal","Anish","Sunil","Anil","Shareef","Sagar","Sachin","Ramakrishna","Swapna","Swee","Binu","Baiju","Babu","Balram","Bharath","Bhavishya","Beena"};

 String q=req.getParameter("q");
 String hint="";

 for(int i=0; i<names.length; i++)
 {
  try{
   if(names[i].toLowerCase().startsWith(q.toLowerCase()))
   {
    if (hint=="")
    {
      hint=names[i];
    }
    else
    {
      hint=hint+" , "+names[i];
	}
  }
 }
 catch(Exception e){}
}

// Set output to "no suggestion" if no hint were found or to the correct values
String response="";
if(hint == "") {
  response="No Suggestion";
}
else {
  response=hint;
}
out.println(response);
}
}