interface Inter1
{
	int x=10,y=20;
	void addNum(int a, int b);
	void subNum(int a, int b);
}